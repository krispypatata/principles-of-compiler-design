# lolcode-interpreter

**CMSC 124 - ST-5L**  
Gabinete  
Ramil  
